return {
    "ryanoasis/vim-devicons",
    config = function()
        vim.cmd("set encoding=UTF-8")
    end,
}
